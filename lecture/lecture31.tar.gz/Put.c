#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>
#include <assert.h>
#include <errno.h>

#define BSIZE 1024

int main(int argc, char *argv[]) {
	int s;
	int sock;
	struct addrinfo hints;
	struct addrinfo *result;
	struct addrinfo *rp;
	int ret;
	int sourceFD;

	char buf[BSIZE];
	if (argc != 5) {
		fprintf(stderr, "Usage: Put host port local_file server_file\n");
		exit(1);
	}

	if ((sourceFD = open(argv[3], O_RDONLY)) == -1) {
		perror(argv[3]);
		exit(1);
	}

	// find the internet address of the server
	memset(&hints, 0, sizeof(hints));
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;

	if ((s=getaddrinfo(argv[1], argv[2], &hints, &result)) != 0) {
		fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(s));
		exit(1);
	}

	// set up socket for TCP and connect to server
	for (rp = result; rp != NULL; rp - rp->ai_next) {
		// try each interface till we find one that works
		if ((sock = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol)) < 0) {
			continue;
		}
		if (connect(sock, rp->ai_addr, rp->ai_addrlen) >= 0) {
			break;
		}
		close(sock);
	}

	if (rp == NULL) {
		fprintf(stderr, "Could not connect to %s\n", argv[1]);
		exit(1);
	}
	freeaddrinfo(result);

	// send request to the server
	buf[0] = 'P';
	strncpy(&buf[1], argv[4], BSIZE-2);
	buf[BSIZE-1] = 0;
		// request consists of P command and file name;
		// make sure file name is null-terminated
	if (write(sock, buf, strlen(buf)+1) == -1) {
		perror("write");
		exit(1);
	}
	// get response from server
	if ((ret = read(sock, buf, BSIZE)) == -1) {
		perror("read from server");
		exit(1);
	}
	if (ret == 0) {
		// shouldn't happen ...
		fprintf(stderr, "unexpected end of file\n");
		exit(1);
	}
	if (buf[0] == 'B') {
		// server says no and supplies reason
		buf[ret] = 0;
		fprintf(stderr, "error from server: %s\n", &buf[1]);
		exit(1);
	}
	if (buf[0] != 'G') {
		// shouldn't happen ...
		fprintf(stderr, "unexpected response from server: %c\n", buf[0]);
		exit(1);
	}
	// good response
	while ((ret = read(sourceFD, buf, BSIZE)) > 0) {
		// get local file contents and send to server
		if (write(sock, buf, ret) == -1) {
			perror("write to server");
			exit(1);
		}
	}
	if (ret == -1) {
		perror("read from local file");
		exit(1);
	}
	return 0;
}
